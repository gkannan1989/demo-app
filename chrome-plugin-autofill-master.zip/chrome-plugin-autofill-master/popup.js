let submitButton = document.getElementById("submit");
let clearButton = document.getElementById("clear");
let vertical = document.getElementById("vertical");
let product = document.getElementById("product");
let customJSON = document.getElementById("customJSON");

// set default values for local page values
let options = { vertical: "", product: "", loaded: false, customJSON: "" };

// Initialize the form with stored option settings
chrome.storage.sync.get("options", (data) => {
  if (Object.keys(data).length !== 0) {
    //console.log("assigning options", data.options);
    Object.assign(options, data.options);
    vertical.setAttribute("value", options.vertical);
    product.setAttribute("value", options.product);
    customJSON.setAttribute("value", options.customJSON)
  } else {
    //console.log("no options found, initializing storage");
    chrome.storage.sync.set({ options });
  }
});

submitButton.addEventListener("click", async (evt) => {
  evt.preventDefault(); // prevents `submit` event from reloading the popup
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const vertical = document.getElementById("vertical").value || "";
  const product = document.getElementById("product").value || "";
  const customJSON = document.getElementById("customJSON").value || "";

  options.vertical = vertical;
  options.product = product;
  options.customJSON = customJSON
  chrome.storage.sync.set({ options });
  /*
  chrome.runtime.sendMessage(text, (response) => {
    console.log(`received response: ${response}`);
  });
  */

  if (vertical !== "" || customJSON !== "") {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      chrome.tabs.update(tabs[0].id, { url: tabs[0].url });
    });
  }
  window.close();
});

clearButton.addEventListener("click", async (evt) => {
  evt.preventDefault(); // prevents `submit` event from reloading the popup
  options.vertical = "";
  options.product = "";
  options.loaded = false
  options.customJSON = ""
  chrome.storage.sync.set({ options });
  vertical.setAttribute("value", options.vertical);
  product.setAttribute("value", options.product);
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.runtime.sendMessage("clear", (response) => {
    console.log(`received response: ${response}`);
    window.close();
  });
});

window.onload = async (event) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  vertical.focus();
  let result;
  console.log("onload triggered")
  try {
    [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: () => getSelection().toString(),
    });

    chrome.storage.sync.get("options", (data) => {
      if (Object.keys(data).length === 0) {
        data.options = { vertical: "", product: "", loaded: false, customJSON: "" };
      }
      //console.log(data);

      if (data.options.vertical !== "" && result === "") {
        document.getElementById("vertical").value = data.options.vertical;
        document.getElementById("product").value = data.options.product;
        document.getElementById("customJSON").value = data.options.customJSON;
      } else {
        //overwrite the default values with selected text
        document.getElementById("vertical").value = result;
        document.getElementById("product").value = data.options.product;
        document.getElementById("customJSON").value = data.options.customJSON;
      }
    });
  } catch (e) {
    return; // ignoring an unsupported page like chrome://extensions
  }
};
