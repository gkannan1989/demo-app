# Questionnarie auto-fill chrome plugin - all environment 

This plug-in can be used at any environment(local, staging, integration, prod..) to pre-fil answers for questionnarie, due to SB compliant related issues first, last name, email, phone number and business name has to be filled manually.

## Plugin
<img src="./images/plugin-3.png" width="200" /> <img src="./images/plugin-2.png" width="200" /> <img src="./images/plugin-1.png" width="200" />


## Install     
[Demo - US](https://simplybusiness.zoom.us/rec/share/w1ROGzqlkC3U40aKsDjHNyXTrIgiOiKSIRP3T2-xGKdFry0Vs2whNmY7QB9LAn_6.gh8x5XmyoPjzU_nv?startTime=1660136455000)

[Demo - UK](https://simplybusiness.zoom.us/rec/share/UZqeJgU6p-QF69CiYet_YuROGUWDBs7_hLhoL-GP39R3c3ye3uF1jJ_Y_Wqy8CVT.zyueOvlCl_K0ZAxY?startTime=1660173065000)

[Demo - Custom JSON pre-fil](https://simplybusiness.zoom.us/rec/share/KSMQr4LioSHC0tQifg-srbsvUwoOI8PKkhefJjhFJ4frN7qhNDgKKWi58Bqdpad_.duVDlYnv4uRHnzI2?startTime=1660173590000)


## Troubleshoot
[Troubleshoot Recording](https://simplybusiness.zoom.us/rec/share/12-SYNpNRbSZ3GuOMwRnyFe_AJvd55m4iWTQQYV3xhMl8XiDkIhHJP9Z1JywuNUr.j-Zw1WdWiGYpaxDB?startTime=1660215563000)

## Update
you need to run the command git pull on the repository branch (or) delete this repository in local system and repeat the [Installation](https://simplybusiness.zoom.us/rec/share/w1ROGzqlkC3U40aKsDjHNyXTrIgiOiKSIRP3T2-xGKdFry0Vs2whNmY7QB9LAn_6.gh8x5XmyoPjzU_nv?startTime=1660136455000) 

## Note
Reason for advising to use unpacked version of plugin is to learn and debug in chrome :) incase curious to know more about building new chrome plugin.

Happy coding!
